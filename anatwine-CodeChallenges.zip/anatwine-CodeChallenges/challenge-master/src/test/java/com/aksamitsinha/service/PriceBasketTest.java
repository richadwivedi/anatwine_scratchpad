package com.aksamitsinha.service;

import com.aksamitsinha.InventoryException;
import com.aksamitsinha.dto.Inventory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created by Amit on 15/01/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:ApplicationContextTest.xml"})
public class PriceBasketTest {
    @Autowired
    private PriceBasket priceBasket;

    @Autowired
    private Inventory inventory;

    @Test
    public void testPriceBasketWithOfferOnApple() throws Exception {

        List<String> ids = new ArrayList<>();
        ids.add("Apple");
        ids.add("Milk");
        ids.add("Bread");
        float price = priceBasket.priceBasket(ids);
        assertEquals(3.0, (double) price, 0.01);
    }

    @Test
    public void testPriceBasketWithNoOffer() throws Exception {

        List<String> ids = new ArrayList<>();
        ids.add("Soup");
        ids.add("Milk");
        float price = priceBasket.priceBasket(ids);
        assertEquals(price, 1.95, 0.01);
    }

    @Test
    public void testPriceBasketWithOfferOnBread() throws Exception {

        List<String> ids = new ArrayList<>();
        ids.add("Soup");
        ids.add("Soup");
        ids.add("Bread");
        float price = priceBasket.priceBasket(ids);
        assertEquals(price, 1.70, 0.01);
    }

    @Test
    public void testPriceBasketWithOfferExpiredDate() throws Exception {

        List<String> ids = new ArrayList<>();
        ids.add("Banana");
        ids.add("Banana");
        float price = priceBasket.priceBasket(ids);
        assertEquals(price, 2.00, 0.01);
    }

    @Test(expected = InventoryException.class)
    public void testException() throws Exception {

        List<String> ids = new ArrayList<>();
        ids.add("NoItem");
        float price = priceBasket.priceBasket(ids);
    }

}
