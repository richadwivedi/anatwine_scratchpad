package com.aksamitsinha.service;

import com.aksamitsinha.InventoryException;
import com.aksamitsinha.dto.Inventory;
import com.aksamitsinha.dto.InventoryItem;
import com.aksamitsinha.service.offer.ICurrentOffer;
import lombok.Getter;
import lombok.Setter;
import org.apache.log4j.Logger;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by Amit on 15/01/2017.
 */
public class PriceBasket {
    private static final Logger logger = Logger.getLogger(PriceBasket.class);
    //setting currency format
    private static final NumberFormat currencyFormat = NumberFormat
            .getCurrencyInstance(Locale.UK);
    @Setter
    @Getter
    private Inventory inventory;
    @Setter
    @Getter
    private Set<ICurrentOffer> offer;

    /**
     * This prices a basket of goods taking into account some special offers defined.
     *
     * @param items Inventory Items
     * @return float Total price of a basket
     * @throws InventoryException
     */
    public float priceBasket(List<String> items) throws InventoryException {
        //check if Item is Available in Inventory
        checkAvalibility(items);
        // creating list of basket items
        List<InventoryItem> basketItems = items.stream().map(a -> inventory.getAvailableItems().
                get(a)).collect(Collectors.toList());

        // calculating subtotal
        float subtotalPrice = getSubtotalPrice(basketItems);

        // returning calculated total price after offer
        return getTotalPrice(basketItems, subtotalPrice);
    }

    /**
     * Calculates subtotal price for the basket before applying discount.
     *
     * @param basketItems List of items of the basket.
     * @return float Subtotal.
     */
    private float getSubtotalPrice(List<InventoryItem> basketItems) {
        float subTotalPrice = 0;
        for (InventoryItem item : basketItems) {
            subTotalPrice = subTotalPrice + item.getPrice();
        }
        System.out.println("Subtotal: " + currencyFormat.format(subTotalPrice));
        return subTotalPrice;
    }

    /**
     * Calculates the price total after applying discounts if available.
     *
     * @param basketItems The items of the basket.
     * @param subtotal    The subtotal.
     * @return float grand total.
     */
    private float getTotalPrice(List<InventoryItem> basketItems, float subtotal) {
        float totalPrice = subtotal;
        for (ICurrentOffer currentOffer : offer) {
            float amount = currentOffer.getValue(basketItems);
            if (amount > 0.000001) {
                System.out.println(currentOffer.getDescription() + ": -"
                        + currencyFormat.format(amount));
                totalPrice = totalPrice - amount;
            }
        }
        if (totalPrice == subtotal) {
            System.out.println("(No offers available)");
        }
        System.out.println("Total price: " + currencyFormat.format(totalPrice));
        return totalPrice;
    }

    /**
     * Checks the basket items against the inventory
     *
     * @param items basket item
     * @throws InventoryException
     */
    private void checkAvalibility(List<String> items) throws InventoryException {
        List<String> unavalableItems = items.stream().filter(item -> !inventory.getAvailableItems().containsKey(item))
                .collect(Collectors.toList());
        if (!unavalableItems.isEmpty()) {
            throw new InventoryException(unavalableItems, "Items not available in stock");
        }
    }
}
