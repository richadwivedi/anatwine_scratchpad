package com.aksamitsinha.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Amit on 15/01/2017.
 */
@Data
@EqualsAndHashCode(of = {"name"})
public class InventoryItem {
    // Inventory Item Name
    private String name;

    //description of the Inventory Item
    private String description;

    //price of Inventory Item
    private float price;
}
