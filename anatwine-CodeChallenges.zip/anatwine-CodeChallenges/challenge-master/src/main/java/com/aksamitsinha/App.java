package com.aksamitsinha;

import com.aksamitsinha.service.PriceBasket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * Created by Amit on 15/01/2017.
 */
public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class);
    private static ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
            new String[]{"ApplicationContext.xml"});

    public static void main(String[] args) {
        PriceBasket priceBasket = appContext.getBean("basket", PriceBasket.class);
        // get their input as a String
        if ((args.length == 0)) {
            List<String> items = userInput();
            priceTheBasket(priceBasket, items);
        } else {
            List<String> itemNames = Arrays.asList(args);
            priceTheBasket(priceBasket, itemNames);
        }
    }

    /**
     * Prices the basket
     *
     * @param priceBasket
     * @param items
     */
    private static void priceTheBasket(PriceBasket priceBasket, List<String> items) {
        try {

            priceBasket.priceBasket(items);
        } catch (InventoryException ie) {
            logger.error("Error in arguments " + ie);
            System.err.println(ie.toString());
        }
    }

    public static List<String> userInput() {
        List<String> items = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Input in the form 'item1 item2 item3 ...'");
        System.out.print("PriceBasket : ");
        String input = scanner.nextLine();
        StringTokenizer st = new StringTokenizer(input, " "); // Space as delimiter
        while (st.hasMoreTokens()) {
            items.add(st.nextToken());
        }
        scanner.close();
        return items;
    }
}
