package com.aksamitsinha;

import java.util.List;

/**
 * Created by Amit on 15/01/2017.
 */
public class InventoryException extends Exception {
    /**
     * This is for creating exception
     *
     * @param names   The List of names of the item causing the exception.
     * @param message The message for exception
     */
    public InventoryException(List<String> names, String message) {
        super(message + "Item " + names);
    }
}
