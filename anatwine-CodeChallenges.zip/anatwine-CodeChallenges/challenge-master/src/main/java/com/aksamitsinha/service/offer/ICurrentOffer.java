package com.aksamitsinha.service.offer;

import com.aksamitsinha.dto.InventoryItem;

import java.util.List;

/**
 * Created by Amit on 15/01/2017.
 */
public interface ICurrentOffer {
    //returns description of the current offer
    public String getDescription();
    // returns value the offer
    public float getValue(List<InventoryItem> basket);
}
