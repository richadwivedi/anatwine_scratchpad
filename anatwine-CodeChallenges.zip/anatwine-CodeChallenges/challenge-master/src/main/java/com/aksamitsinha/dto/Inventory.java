package com.aksamitsinha.dto;

import lombok.Data;

import java.util.Map;

/**
 * Created by Amit on 15/01/2017.
 */
@Data
public class Inventory {
    // The Map item containing relationship of inventory items available in current Inventory.
    private Map<String, InventoryItem> availableItems;
}
