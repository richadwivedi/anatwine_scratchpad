package com.aksamitsinha.service.offer;

import com.aksamitsinha.dto.InventoryItem;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.apache.log4j.Logger;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This Class provides value and description of two types of offers
 * i) Discount available on the purchase of a single item
 * ii) Discount available based on the purchase of another item
 * Flexible to allow future changes to the product list and/or discounts applied but with the same kind of discounts.
 * Created by Amit on 15/01/2017.
 */
@Data
public class SpecialOffer implements ICurrentOffer {

    private static final Logger logger = Logger.getLogger(SpecialOffer.class);

    // Description of the offer
    private String description;
    // Required Number of Items on which offer can be availed
    private int reqNumberItem;
    // Offer Starting Date
    private Date initDate;
    //Offer End Date
    private Date endDate;
    //Offer available of which Item
    private InventoryItem offerOnItem;
    //Offer Offered against another Item
    private InventoryItem itemOffered;
    // What percentage of discount to be applied
    @Setter(AccessLevel.NONE)
    private double percentage;

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDescription() {
        return description;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public float getValue(List<InventoryItem> basket) {
        Date currentDate = new Date();
        long numTimesDiscount = getTimesToApply(basket);
        if (initDate.getTime() <= currentDate.getTime()
                && currentDate.getTime() <= endDate.getTime()) {
            List<InventoryItem> itemsToDiscount = basket.stream()
                    .filter(item -> item.equals(itemOffered))
                    .limit(numTimesDiscount).collect(Collectors.toList());

            float discount = (float) itemsToDiscount.stream()
                    .mapToDouble(item -> item.getPrice() * percentage / 100)
                    .sum();
            return discount;

        } else return (float) 0.0;
    }

    /**
     * Percentage of offer to be applied
     *
     * @param percentage
     */
    public void setPercentage(double percentage) {
        this.percentage = percentage;
        assert ((percentage >= 0) && (percentage <= 100));
    }

    /**
     * Offer Applied within the one item is offered against another item
     *
     * @param basket List of Inventory Item
     * @return long
     */
    private long getTimesToApply(List<InventoryItem> basket) {
        long totalOfferedItemNumber = basket.stream().filter(item -> item.equals(offerOnItem)).count();
        return totalOfferedItemNumber / reqNumberItem;
    }

}
