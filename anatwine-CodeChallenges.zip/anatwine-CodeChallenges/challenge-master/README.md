# The challenge
Write a program in Java (JDK 8 / Maven) and associated unit tests that
can price a basket of goods taking into account some special offers.

The goods that can be purchased, together with their normal prices are:

-   Soup – 65p per tin
-   Bread – 80p per loaf
-   Milk – £1.30 per bottle
-   Apples – £1.00 per bag

Current special offers:

-   Apples have a 10% discount off their normal price this week
-   Buy 2 tins of soup and get a loaf of bread for half price

The program should accept a list of items in the basket and output the
subtotal, the special offer discounts and the final price.

Input should be via the command line in the form
`PriceBasket item1 item2 item3 ...`

For example:

    Prciebasket Apples Milk Bread

Output should be to the console, for example:

    Subtotal: £3.10
    Apples 10% off: -10p
    Total: £3.00

If no special offers are applicable the code should output:

    Subtotal: £1.30
    (No offers available)
    Total proce: £1.30

The code and design should meet these requirements, but be sufficiently
flexible to allow future changes to the product list and/or discounts
applied.

The code should be well structured, commented, have error handling
and be tested.

## Solution
I believe the main objective of this challenge was to make sure that the design meets the above requirements as well as provides a flexibitily to add future changes easily. Use of a DB would have been ideal in a real world scenario but to keep things simple I made use of light weight framework - **Spring** to create a **standalone Java application**. I have provided the basic JUnit testcases, there are chances for improvement.


Making use of Spring framework and Strategy pattern gave me an apportunity to provide the basic required functionality but also flexibility to update the product list and discounts applied. With this example I have implemented the required functionality i.e.

The goods that can be purchased, together with their normal prices are:

-   Soup – 65p per tin
-   Bread – 80p per loaf
-   Milk – £1.30 per bottle
-   Apples – £1.00 per bag

***but also have demostrated that with a simple addition to the application context it is quite easy to add another item to the list which is Banana with this solution***  
- Banana - £1.00 each.  
***Also I can easily add another discount i.e.***
- Buy 2 get 1 free on Banana.


### Technical Specification

#### Requirement
- Maven 3.3.9
- Java 8

#### Build Instructions

##### Local Build:
- Install maven
- Install jdk 1.8
- Download code
- In the local directory run "mvn install"

#### Usage

##### Local Setup:
``` run app.java as java application```  
on command line provide input in the form ` item1 item2 item3 ... `  
i.e. ``` Apple Milk Soup...```

##### Challenge.jar 
Provided Jar along with the Repo.

run ``` java -jar Challenge.jar ``` and provide input in the form ` PriceBasket item1 item2 item3 ...` i.e. ` Apple Milk Soup...`

**Or**

run ``` java -jar Challenge.jar item1 item2 item3 ...``` i.e. ``` java -jar Challenge.jar Apple Soup Soup Banana Banana...``

***NOTE*** - The items are case sensitive and should be provided as Apple, Banana etc.
