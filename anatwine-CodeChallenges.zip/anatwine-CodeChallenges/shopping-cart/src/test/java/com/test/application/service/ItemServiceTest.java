package com.test.application.service;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.test.application.model.Item;

public class ItemServiceTest {
	
	ItemService service = new ItemService();

	@Test
	public void testReadInvalidItems() {
		assertEquals(service.readItems(null).size(), 0);
		assertEquals(service.readItems(new String[1]).size(), 0);
		assertEquals(service.readItems(new String[]{"foo"}).size(), 0);
	}
	
	@Test
	public void testReadValidItems(){
		List<Item> items;
		items = service.readItems(new String[]{"PriceBasket", "Apples"});
		assertEquals(items.size(), 1);
		assertTrue(items.contains(Item.APPLES));
	}

	@Test
	public void testReadValidMultipleItems(){
		List<Item> items;
		items = service.readItems(new String[]{"PriceBasket", "Apples", "Soup", "apples", "Bread"});
		assertEquals(items.size(), 4);
		assertTrue(items.contains(Item.APPLES));
		assertTrue(items.contains(Item.SOUP));
		assertTrue(items.contains(Item.BREAD));
	}
	
	@Test
	public void testCalculateSubTotal(){
		List<Item> items = Arrays.asList(new Item[] {Item.APPLES, Item.BREAD, Item.APPLES});
		double total = service.calculateSubTotal(items);
		assertTrue(total == (Item.APPLES.getPrice()*2) + Item.BREAD.getPrice());
	}
}
