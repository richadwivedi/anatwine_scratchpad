package com.test.application;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

/**
 * Created by rdwivedi on 08/02/2017.
 */
public class ShoppingCartApplicationTest {

    @Test
    public void runApplication()
    {
        String[] args = new String[]{"PriceBasket", "Apples", "Soup", "apples", "Bread"};
        ShoppingCartApplication.main(args);
    }
}
