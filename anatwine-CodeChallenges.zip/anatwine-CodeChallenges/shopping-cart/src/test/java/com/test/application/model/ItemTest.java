package com.test.application.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class ItemTest {

	@Test
	public void testFindByNameInvalid() {
		assertNull(Item.findByNameIgnoreCase("foo"));
		assertNull(Item.findByNameIgnoreCase("soups"));
		assertNull(Item.findByNameIgnoreCase("mills"));
		assertNull(Item.findByNameIgnoreCase("apple"));
	}
	
	@Test
	public void testValidItem(){
		assertEquals(Item.APPLES, Item.findByNameIgnoreCase("aPpLeS"));
		assertEquals(Item.APPLES, Item.findByNameIgnoreCase("Apples"));
		assertEquals(Item.BREAD, Item.findByNameIgnoreCase("BREAD"));
		assertEquals(Item.SOUP, Item.findByNameIgnoreCase("soup"));
	}

}
