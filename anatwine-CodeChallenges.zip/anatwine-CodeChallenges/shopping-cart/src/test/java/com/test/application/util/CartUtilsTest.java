package com.test.application.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class CartUtilsTest {

	@Test
	public void testFormatOne() {
		assertEquals("�1.10", CartUtils.formatAmount(1.1));
	}
	
	@Test
	public void testFormatTwo() {
		assertEquals("10p", CartUtils.formatAmount(0.1));
	}

}
