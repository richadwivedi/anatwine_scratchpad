package com.test.application.service;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;

public class OfferServiceTest {
	
	OfferService service = new OfferService();
	
	@Before
	public void init(){
		service.registerOffer(new AppleOffer());
		service.registerOffer(new SoupOffer());
	}

	@Test
	public void testApplyOffersWithoutRegistration() {
		OfferService service = new OfferService();
		List<Item> items = Arrays.asList(new Item[] {Item.APPLES, Item.BREAD});
		assertEquals(0, service.applyOffers(items).size());
	}
	
	@Test
	public void testApplyNoOffers(){
		List<Item> items = Arrays.asList(new Item[] {Item.SOUP, Item.BREAD});
		assertEquals(0, service.applyOffers(items).size());
	}
	
	@Test
	public void testApplyAppleOffer(){
		Date now = new Date();
		Date endDate = new AppleOffer().getEndDate();
		if(now.before(endDate)){
			List<Item> items = Arrays.asList(new Item[] {Item.APPLES});
			List<OfferDto> offers = service.applyOffers(items);
			assertEquals(offers.size(), 1);
			assertTrue(Item.APPLES.getPrice()*0.1 == offers.get(0).getDiscount());
		}
	}
	
	@Test
	public void testApplySoupOfferNoBread(){
		List<Item> items = Arrays.asList(new Item[] {Item.SOUP, Item.SOUP});
		assertEquals(service.applyOffers(items).size(), 0);
	}
	
	@Test
	public void testApplySoupOfferWithBread(){
		List<Item> items = Arrays.asList(new Item[] {Item.SOUP, Item.SOUP, Item.BREAD, Item.SOUP});
		List<OfferDto> offers = service.applyOffers(items);
		assertEquals(offers.size(), 1);
		assertTrue(offers.get(0).getDiscount() == Item.BREAD.getPrice() * 0.5);
		
		items = Arrays.asList(new Item[] {Item.SOUP, Item.SOUP, Item.BREAD, Item.SOUP, Item.SOUP});
		offers = service.applyOffers(items);
		assertEquals(offers.size(), 1);
		assertTrue(offers.get(0).getDiscount() == Item.BREAD.getPrice() * 0.5);
	}
	
	@Test
	public void applyMultipleSoupBreadOffer(){
		List<Item> items = Arrays.asList(new Item[] {Item.SOUP, Item.SOUP, Item.BREAD, Item.SOUP, Item.SOUP, Item.BREAD});
		List<OfferDto> offers = service.applyOffers(items);
		assertEquals(offers.size(), 1);
		assertTrue(offers.get(0).getDiscount() == Item.BREAD.getPrice());
	}
	
	@Test
	public void applyAllOffers(){
		Date now = new Date();
		Date endDate = new AppleOffer().getEndDate();
		if(now.before(endDate)){
			List<Item> items = Arrays.asList(new Item[] {Item.SOUP, Item.SOUP, Item.BREAD, Item.APPLES});
			List<OfferDto> offers = service.applyOffers(items);
			assertEquals(offers.size(), 2);
			double totalDiscount = offers.stream()
					.map(o -> o.getDiscount())
					.mapToDouble(d -> d)
					.sum();
			assertTrue(totalDiscount == (Item.APPLES.getPrice()*0.1 + Item.BREAD.getPrice()*0.5));
		}
	}

}
