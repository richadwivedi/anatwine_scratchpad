package com.test.application.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.test.application.model.Item;

/**
 * Service class designed to perform Item related operations
 * @author Darshan Mehta
 *
 */
public class ItemService {
	
	/**
	 * Reads items off arguments and constructs Item list. It ignores items that do not match.
	 * @param args command line args
	 * @return list of items
	 */
	public List<Item> readItems(String[] args){
		if(null == args || args.length < 2){
			return Collections.emptyList();
		}
		
		List<Item> items = new ArrayList<>();
		
		for(int i=1 ; i<args.length ; i++){
			Item item = Item.findByNameIgnoreCase(args[i]);
			if(null != item){
				items.add(item);
			}
		}
		
		return items;
	}
	
	/**
	 * Calculates sub total of all the items
	 * @param items list of items
	 * @return subtotal
	 */
	public double calculateSubTotal(List<Item> items){
		return items.stream()
				.mapToDouble(i -> i.getPrice())
				.sum();
	}

}
