package com.test.application.model;

import java.util.Arrays;
import java.util.Optional;

/**
 * Item enum, used to hold different items and their prices
 * @author Darshan Mehta
 *
 */
public enum Item {
	
	SOUP("Soup", 0.65),
	BREAD("Bread", 0.80),
	MILK("Milk", 1.3),
	APPLES("Apples", 1.0);
	
	private final String name;
	private final double price;
	
	private Item(String name, double price){
		this.name = name;
		this.price = price;
	}

	public static Item findByNameIgnoreCase(String name){
		
		Optional<Item> item = Arrays.stream(values())
		.filter(i -> i.name.equalsIgnoreCase(name))
		.findFirst();
		
		if(item.isPresent()){
			return item.get();
		}else{
			return null;
		}
	}
	
	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}
}