package com.test.application.service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;

/**
 * Implementation class for soup offer. 
 * @author Darshan Mehta
 *
 */
public class SoupOffer extends Offer{

	/**
	 * Applies soup offer
	 * 
	 * @param items list of items
	 * @return OfferDto offer object if applicable
	 */
	@Override
	public OfferDto apply(List<Item> items) {
		OfferDto offer = null;
		Map<Item, Long> itemMap = items.stream()
		.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		
		if(itemMap.containsKey(Item.SOUP) && itemMap.containsKey(Item.BREAD)){
			//Check number of soup tins and bread loaves
			long soups = itemMap.get(Item.SOUP);
			long breads = itemMap.get(Item.BREAD);
			
			if(soups >= 2){
				double breadPrice = Item.BREAD.getPrice();
				double discount = 0d;
				//Make sure one discount applies to one bread unit only
				for(int i=1 ; i<= soups/2 ; i++){
					if(i <= breads){
						discount += breadPrice*0.5;
					}
				}
				offer = new OfferDto("Bread 50% off: ", discount);
			}
		}
		return offer;
	}

}
