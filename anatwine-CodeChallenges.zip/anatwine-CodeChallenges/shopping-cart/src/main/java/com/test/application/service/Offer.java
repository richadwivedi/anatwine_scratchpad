package com.test.application.service;

import java.util.List;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;

/**
 * Abstract class, extended by different offer implementations.
 * It can be used to hold common states of offers. It can also be extended to
 * have methods common across all the offers.
 * @author Darshan Mehta
 *
 */
public abstract class Offer {

	public abstract OfferDto apply(List<Item> items);
}
