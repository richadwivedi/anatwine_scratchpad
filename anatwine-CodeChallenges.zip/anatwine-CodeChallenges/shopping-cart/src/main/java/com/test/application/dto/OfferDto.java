package com.test.application.dto;

/**
 * Data transfer class, used to hold details of applied offers
 * @author Darshan Mehta
 *
 */
public class OfferDto {
	
	private String text;
	private double discount;

	public OfferDto(String text, double discount){
		this.text = text;
		this.discount = discount;
	}
	
	public String getText() {
		return text;
	}
	public double getDiscount() {
		return discount;
	}
}
