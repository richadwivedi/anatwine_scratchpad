package com.test.application;

import java.util.Arrays;
import java.util.List;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;
import com.test.application.service.AppleOffer;
import com.test.application.service.ItemService;
import com.test.application.service.OfferService;
import com.test.application.service.SoupOffer;
import com.test.application.util.CartUtils;

/**
 * Driver class of shopping cart application
 * @author Darshan Mehta
 *
 */
public class ShoppingCartApplication {
	
	public static void main(String[] args) {
	
		ItemService itemService = new ItemService();
		
		OfferService offerService = new OfferService();
		offerService.registerOffer(new AppleOffer());
		offerService.registerOffer(new SoupOffer());
		
		List<Item> items = itemService.readItems(args);
		
		System.out.println("Input : " + Arrays.asList(args));
		
		if(items.isEmpty()){
			System.out.println("Invalid or no items.");
			System.exit(0);
		}
		
		
		double subTotal = itemService.calculateSubTotal(items);
		double total = subTotal;
		
		List<OfferDto> appliedOffers = offerService.applyOffers(items);
		
		System.out.println("Subtotal: " + CartUtils.formatAmount(subTotal));
		if(appliedOffers.isEmpty()){
			System.out.println("(No offers available)");
		}
		for(OfferDto offer : appliedOffers){
			System.out.println(offer.getText() + "-" + CartUtils.formatAmount(offer.getDiscount()));
			total -= offer.getDiscount();
		}
		System.out.println("Total: " + CartUtils.formatAmount(total));
	}
}