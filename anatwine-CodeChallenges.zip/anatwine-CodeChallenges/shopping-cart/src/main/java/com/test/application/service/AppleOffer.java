package com.test.application.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;

/**
 * Implementation class for Apples' offer. 
 * @author Darshan Mehta
 *
 */
public class AppleOffer extends Offer{
	
	private Date startDate;
	private Date endDate;
	
	public AppleOffer() {
		try{
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			startDate = dateFormat.parse("2017-02-06");
			endDate = dateFormat.parse("2017-02-12");
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Applies apple offer
	 * 
	 * @param items list of items
	 * @return OfferDto offer object if applicable
	 */
	@Override
	public OfferDto apply(List<Item> items) {
		OfferDto offer = null;
		//Check whether current date is between start and end date
		Date today = new Date();
		if(today.getTime() >= startDate.getTime() && today.getTime() <= endDate.getTime()){
			//Now, check count of apples
			long apples = items.stream()
			.filter(i -> i.equals(Item.APPLES))
			.count();
			
			if(apples > 0){
				offer = new OfferDto("Apples 10% off: ", 0.10*apples);
			}
		}
		return offer;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

}
