package com.test.application.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * Utility class to perform generic operations for shopping cart
 * @author Darshan Mehta
 *
 */
public class CartUtils {
	
	/**
	 * Formats the amount by adding pound/pence sign
	 * @param amount decimal representation of amount
	 * @return String representation with pound/pence sign
	 */
	public static String formatAmount(double amount){
		NumberFormat formatter = new DecimalFormat("#0.00");   
		if(amount >= 1){
			return "�" + formatter.format(amount);
		}else{
			return (long) (amount*100) + "p";
		}
	}

}
