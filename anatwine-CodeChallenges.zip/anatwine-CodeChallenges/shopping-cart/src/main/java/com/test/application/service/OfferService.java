package com.test.application.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.test.application.dto.OfferDto;
import com.test.application.model.Item;

/**
 * Service class designed to perform offer related operations
 * @author Darshan Mehta
 *
 */
public class OfferService {
	
	private List<Offer> offers = new ArrayList<>();
	
	/**
	 * Registers all the available offers. Should be called at startup.
	 * @param offer
	 */
	public void registerOffer(Offer offer){
		offers.add(offer);
	}
	
	/**
	 * Iterates through registered offers and applies to the items present in shopping basket 
	 * @param items the items in shopping basket
	 * @return list of offers applicable
	 */
	public List<OfferDto> applyOffers(List<Item> items){
		return offers.stream()
				.map(o -> o.apply(items))
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
	}

}
