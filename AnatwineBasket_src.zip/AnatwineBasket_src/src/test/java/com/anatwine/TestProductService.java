package com.anatwine;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;

import com.anatwine.core.Basket;
import com.anatwine.dao.IProductDAO;
import com.anatwine.dao.ProductDAO;
import com.anatwine.model.Product;
import com.anatwine.service.IProductService;
import com.anatwine.service.ProductService;
import com.anatwine.utils.AppUtil;

import org.hibernate.jdbc.Expectation;
import org.junit.Assert.*;

/**
 * Created Custom configuration for disabling the commandline runner arguments
 * which we don't need for testing purpose.
 * 
 * @author Mustansar Saeed
 *
 */

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestAnatwineBasketApp.class, 
initializers = ConfigFileApplicationContextInitializer.class)
@Import(TestAnatwineBasketApp.class)
public class TestProductService {
	@MockBean
    private TestEntityManager entityManager;
	
	@Autowired
	IProductService productService;
	
	@Autowired
	Basket basket;
	
	@Before
	public void setUp() {
//		Product p = Product.newProduct("addProduct", "Product 4", "12345", "12.2", "1");
//		productService.addProduct(p);
	}
	
	@Test
	public void testProductsCount() {
		assertEquals(6, productService.getAllProducts().size());		
	}	
	
	@Test
	public void addSingleProduct() {
		basket.clear();
		
		assertEquals(1, productService.getAllProductsForNames("1111").size());
		Product product = productService.getAllProductsForNames("1111").get(0);
		basket.addProduct(product);
		
		assertEquals((double)product.getUnitPrice(), basket.computeTotal(false), 0);
	}
	
	/**
	**	Price of Barcode 1111 = 12.12 * 2 = 24.24
	**/
	@Test
	public void addSameProductTwoTimes() {
		basket.clear();

		Product product = productService.getAllProductsForNames("1111").get(0);
		basket.addProduct(product);
		basket.addProduct(product);
		
		assertEquals(2, basket.getProductQuantity(product));
		assertEquals(12.12 * 2, basket.computeTotal(false), 0);
	}
	
	/**
	 * 	Price of Barcode 1111 = 12.12
	 *  Price of Barcode 1144 = 10.25
	 */
	@Test
	public void multipleProductsSubtotal_without_discount() {
		basket.clear();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			productService.addProductDiscount("1111", 10.0, new Timestamp(format.parse("2000-09-12").getTime()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String expectedResult = "Subtotal:    22.37\n" + 
				"(No offers available)\n" + 
				"Total: 22.37";
		
		String actualResult = basket.addProductsToCart("1111", "1144");
		
		assertEquals(expectedResult, actualResult);
	}
	
	@Test
	public void multipleProductsSubtotal_with_a_discount_on_oneItem() {
		basket.clear();
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			productService.addProductDiscount("1111", 10.0, new Timestamp(format.parse("2017-09-12").getTime()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String expectedResult = "Subtotal:    22.37\n" + 
				"Chicken Fajita 10.0% Off: -10.00\n" + 
				"Total: 21.16";
		
		String actualResult = basket.addProductsToCart("1111", "1144");
		
		assertEquals(expectedResult, actualResult);
	}
}
