package com.anatwine.utils;

/**
 * Single class to hold the application constants
 * 
 * @author Mustansar Saeed
 *
 */
public class Constants {
	public static final String ADD_PRODUCT = "addProduct";
	public static final String LIST_PRODUCT = "listProducts";
	public static final String ADD_PRODUCT_DISCOUNT = "addProductDiscount";
	public static final String LIST_PRODUCT_DISCOUNT = "listProductDiscounts";
	
	public static final String ArgumentMissingException = "Some arguments are missing for adding product (addProduct). "
			+ "Please enter as productName productBarCode productPrice productQuantity.";
	public static final String ArgumentMissingForDiscount = "Some arguments are missing for adding product discount (addProductDiscount). "
			+ "Please enter as barcode discount endDate.";
	public static final String ShouldContainAlphabets = "Product Name should contain alphabets.";
	public static final String ShouldContainDigitsOnly = "should contain digits only.";
	public static final String ShouldContainNumberOrDecimal = "should contain numbers or number with decimal points";
	public static final String PriceShouldContainDigitsOnly = "Quantity should contain digits only.";
	public static final String Barcode = "Barcode ";
	public static final String Price = "Price ";
	public static final String Discount = "Discount ";
	public static String validArgumentsAre = "Valid arguments are " + ADD_PRODUCT + ", " + LIST_PRODUCT + ", " + ADD_PRODUCT_DISCOUNT;
}
