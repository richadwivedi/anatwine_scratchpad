package com.anatwine.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.anatwine.model.Product;
import com.anatwine.service.IProductService;
import com.anatwine.service.ProductService;

/**
 * Single utility class to have the helper and validation methods
 * 
 * @author Mustansar Saeed
 *
 */
public class AppUtil {
	public static boolean validateArguments(String...args) {
		if(args.length < 5) {
			return false;
		}
		
		isAlphabet(args[1]);
		
		isDigit(args[2], Constants.Barcode + Constants.ShouldContainDigitsOnly);
		
		isNumberOrDecimalPoint(args[3], Constants.ShouldContainNumberOrDecimal);
		
		isDigit(args[4], Constants.PriceShouldContainDigitsOnly);
		
		return true;
	}
	
	public static boolean isAlphabet(String arg) {
		return arg.matches("[a-zA-Z ]+");
	}
	
	public static boolean isDigit(String arg, String message) {
		boolean isDigit = arg.matches("[0-9]+");
		if(!isDigit) {
			throw new IllegalArgumentException(message);
		}
		
		return isDigit;
	}
	
	public static boolean isNumberOrDecimalPoint(String arg, String message) {
		boolean isNumberOrDecimalPoint = arg.matches("[0-9.]*") || arg.matches("\"\\\\d*\\\\.?\\\\d+\"");
		if(!isNumberOrDecimalPoint) {
			throw new IllegalArgumentException(message);
		}
		
		return isNumberOrDecimalPoint;
	}

	public static boolean isValidDateFormat(String date) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			format.parse(date);
			return true;
		} catch (Exception e) {
			throw new IllegalArgumentException("Date should be in the format yyyy-MM-dd");
		}
	}
}
