package com.anatwine.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "discountOffer")
public class DiscountOffer {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name = "productBarCode")
	private String productBarCode;
	
	@Column(name = "discount")
	private double discount;
	
	@Column(name = "endDate")
	private Timestamp endDate;
	
	public DiscountOffer() {
		
	}
	
	private DiscountOffer(String productBarCode, double discount, Timestamp endDate) {
		this.productBarCode = productBarCode;
		this.discount = discount;
		this.endDate = endDate;
	}
	
	public static DiscountOffer createNewDiscountOffer(String barcode, double discount, Timestamp endDate) {
		return new DiscountOffer(barcode, discount, endDate);
	}

	public String getProductBarCode() {
		return productBarCode;
	}

	public void setProductBarCode(String productBarCode) {
		this.productBarCode = productBarCode;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	
	
}
