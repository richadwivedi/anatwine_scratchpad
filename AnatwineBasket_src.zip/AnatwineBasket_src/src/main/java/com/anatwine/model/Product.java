package com.anatwine.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="productId")
	private int productId;
	
	@Column(name = "productName")
	private String productName;
	
	@Column(name = "productBarCode")
	private String productBarCode;
	
	@Column(name = "unitPrice")
	private double unitPrice;
	
	@Column(name = "quantity")
	private Integer quantity;

	public Product() {

	}
//
	private Product(String productName, String productBarCode, String unitPrice, String quantity) {
		this.productName = productName;
		this.productBarCode = productBarCode;
		this.unitPrice = Double.parseDouble(unitPrice);
		this.quantity = Integer.parseInt(quantity);
	}
	
	public static Product newProduct(String...args) {
		return new Product(args[1], args[2], args[3], args[4]);
	}

	
	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	
	public double priceForQuantity(int quantity) {
		return unitPrice * quantity;
	}
	
	public double getUnitPriceForDiscount(double discount) {
		return unitPrice - (double)((discount / 100) * unitPrice);
	}

	public String getProductBarCode() {
		return productBarCode;
	}

	public void setProductBarCode(String productBarCode) {
		this.productBarCode = productBarCode;
	}
	
	
}  