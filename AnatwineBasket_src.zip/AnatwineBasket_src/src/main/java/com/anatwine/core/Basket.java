package com.anatwine.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.anatwine.AnatwineBasketApp;
import com.anatwine.model.DiscountOffer;
import com.anatwine.model.Product;
import com.anatwine.service.IProductService;

@Service
public class Basket {
	@Autowired
	IProductService productService;

	private LinkedHashMap<Product, Integer> basketProducts = new LinkedHashMap<>();
	private HashMap<String, Double> discountMaps = new HashMap<>();

	public Basket() {
		basketProducts = new LinkedHashMap<>();
	}

	public Map<Product, Integer> getItems() {
		return basketProducts;
	}

	public void addProduct(Product product){
		int previousQuantity = basketProducts.containsKey(product)
				? basketProducts.get(product)
						: 0;
				basketProducts.put(product, previousQuantity + 1);
	}
	
	public int getProductQuantity(Product product) {
		return basketProducts.get(product);
	}

	public double computeTotal(boolean withOffer) {
		List<DiscountOffer> discounts = productService.getAllProductDiscounts();

		for(DiscountOffer offer : discounts) {
			discountMaps.put(offer.getProductBarCode(), offer.getDiscount());
		}

		double result = 0.0;
		for (Product product : basketProducts.keySet()) {
			if( discountMaps.containsKey(product.getProductBarCode()) && withOffer) {
				result += product.getUnitPriceForDiscount(discountMaps.get(product.getProductBarCode())) * basketProducts.get(product);
			} else {
				result += product.getUnitPrice() * basketProducts.get(product);
			}
		}
		return result;
	}

	public void clear() {
		basketProducts.clear();
	}

	public String addProductsToCart(String... names) {
		List<Product> products = productService.getAllProductsForNames(names);
		String computeString = "";
		if(products == null || products.size() == 0) {
			computeString = "No products found in the system with the given names.";
			System.out.println(computeString);
		} else {
			for(Product product : products) {
				addProduct(product);
			}

			computeString = toString();
			System.out.println(computeString);
		}
		
		return computeString;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(String.format("%s %8.2f", "Subtotal:", computeTotal(false)));
		boolean anyDiscountAvailable = false;
		for (Product product : basketProducts.keySet()) {
			if( discountMaps.containsKey(product.getProductBarCode())) {
				sb.append("\n");
				sb.append(String.format("%s %s%% Off: -%.2f", product.getProductName(), 
						discountMaps.get(product.getProductBarCode()), discountMaps.get(product.getProductBarCode())));
				
				anyDiscountAvailable = true;
			}
			
		}
		
		if(!anyDiscountAvailable) {
			sb.append("\n(No offers available)");
		}
		
		sb.append("\n");
		sb.append(String.format("%s %4.2f", "Total:", computeTotal(true)));
		return sb.toString();
	}
}