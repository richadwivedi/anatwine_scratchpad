package com.anatwine.dao;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.anatwine.model.DiscountOffer;
import com.anatwine.model.Product;

@Transactional
@Repository
public class ProductDAO implements IProductDAO {
	@PersistenceContext	
	private EntityManager entityManager;	

	@Override
	public Product getProductById(Integer productId) {
		return entityManager.find(Product.class, productId);
	}

	/**
	 * Get all products from the database in the order the products were added in the system
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProducts() {
		String hql = "FROM Product as product order by product.productId";
		List<Product> products =  entityManager.createQuery(hql).getResultList();
		 if(products == null)
			 products = new ArrayList<>();
		 
		 return products;
	}

	/**
	 * Get all products from the system either by names or by barcodes entered from the commandline
	 * 
	 */
	
	@Override
	public List<Product> getAllProductsForNames(String... names){
		String hql = "FROM Product as product WHERE product.productName IN :nameList or product.productBarCode IN :barcodeList";
		TypedQuery<Product> query = entityManager.createQuery(hql, Product.class);
		query.setParameter("nameList", Arrays.asList(names));
		query.setParameter("barcodeList", Arrays.asList(names));

		List<Product> products = (List<Product>) query.getResultList();

		return products;
	}

	@Override
	public void addProduct(Product product) {
		entityManager.persist(product);
	}

	@Override
	public void updateProduct(Product product) {
		Product productExisting = getProductById(product.getProductId());
		
		productExisting.setUnitPrice(product.getUnitPrice());
		productExisting.setProductBarCode(product.getProductBarCode());
		productExisting.setProductName(product.getProductName());
		productExisting.setQuantity(product.getQuantity());
		
		entityManager.flush();
	}

	@Override
	public void deleteProduct(Integer productId) {
		entityManager.remove(getProductById(productId));
	}

	/**
	 * Find product from the system based on product name and barcode
	 * 
	 */
	@Override
	public boolean productExists(String productName, String barcode) {
		String hql = "FROM Product as product WHERE product.productName = ? or product.productBarCode = ?";
		int count = entityManager.createQuery(hql).setParameter(1, productName)
				.setParameter(2, barcode).getResultList().size();
		return count > 0;
	}

	@Override
	public boolean productExists(int productId) {
		String hql = "FROM Product as product WHERE product.productId = ?";
		int count = entityManager.createQuery(hql).setParameter(1, productId).getResultList().size();
		return count > 0;
	}

	@Override
	public Product getProductByName(String productName) {
		String hql = "FROM Product as p WHERE p.productName = ? ";
		List<Product> products = entityManager.createQuery(hql).setParameter(1, productName).getResultList();
		if(products == null || products.size() == 0)
			return null;
		return products.get(0);
	}

	@Override
	public Product getProductByBarcode(String barcode) {
		return null;
	}

	/**
	 *	Add product discount with ending date when this discount will vanish.
	 *	If not exist add in the DB otherwise update it. 
	 * 
	 */
	@Override
	public void addProductDiscount(String barcode, double discount, Timestamp endDate) {
		String hql = "FROM DiscountOffer as discount WHERE discount.productBarCode = ?";
		DiscountOffer discountOffer = null;
		try {
			discountOffer = (DiscountOffer)entityManager.createQuery(hql).setParameter(1, barcode).getSingleResult();
		}
		catch (Exception nre){
			nre.printStackTrace();
		}

		if(discountOffer == null) {
			discountOffer = DiscountOffer.createNewDiscountOffer(barcode, discount, endDate);
			entityManager.persist(discountOffer);		
		} else {
			discountOffer.setDiscount(discount);
			discountOffer.setEndDate(endDate);
			entityManager.flush();
		}

	}

	@Override
	public List<DiscountOffer> getAllProductDiscounts() {
		String hql = "FROM DiscountOffer as discOffer where discOffer.endDate > :now order by discOffer.id";
		Query query = entityManager.createQuery(hql).setParameter("now", new Timestamp(System.currentTimeMillis()));
		
		if(query != null)
			return (List<DiscountOffer>) query.getResultList();
		
		return null;
	}
} 