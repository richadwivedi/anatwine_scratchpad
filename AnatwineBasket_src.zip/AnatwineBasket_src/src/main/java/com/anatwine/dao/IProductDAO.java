package com.anatwine.dao;

import java.sql.Timestamp;
import java.util.List;

import com.anatwine.model.DiscountOffer;
import com.anatwine.model.Product;
public interface IProductDAO {
    List<Product> getAllProducts();
    List<Product> getAllProductsForNames(String...names);
    List<DiscountOffer> getAllProductDiscounts();
    Product getProductById(Integer productId);
    Product getProductByName(String productName);
    Product getProductByBarcode(String barcode);
    void addProduct(Product product);
    void addProductDiscount(String barcode, double discount, Timestamp endDate);
    void updateProduct(Product product);
    void deleteProduct(Integer productId);
    boolean productExists(int productId);
    boolean productExists(String productName, String barcode);
} 
