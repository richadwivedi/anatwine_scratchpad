package com.anatwine;


import com.anatwine.core.Basket;
import com.anatwine.model.Product;
import com.anatwine.service.ProductService;
import com.anatwine.utils.AppUtil;
import com.anatwine.utils.Constants;
import com.anatwine.service.IProductService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import static java.lang.System.exit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Entry point of the application which takes arguments from the command line and then produces the 
 * results accordingly. addProduct, listProducts, addDiscount etc.
 * 
 * @author Mustansar Saeed
 *
 */

@SpringBootApplication
@ComponentScan("com.anatwine")
public class AnatwineBasketApp implements CommandLineRunner {
	public static final Logger log = LoggerFactory.getLogger(AnatwineBasketApp.class);
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private Basket basket;

	public static void main(String[] args) throws Exception {
		SpringApplication app = new SpringApplication(AnatwineBasketApp.class);
		app.setBannerMode(Banner.Mode.OFF);
		app.run(args);
	}

	@Override
	public void run(String... args) throws Exception {
		if (args.length > 0 ) {
			if(args[0].toString().equalsIgnoreCase(Constants.ADD_PRODUCT)) {
				addProduct(args);
			} else if(args[0].toString().equalsIgnoreCase(Constants.ADD_PRODUCT_DISCOUNT)) {
				addProductDiscount(args);
			} else if(args[0].toString().equalsIgnoreCase(Constants.LIST_PRODUCT)) {
				productService.listProducts();
			} else if(args[0].toString().equalsIgnoreCase(Constants.LIST_PRODUCT_DISCOUNT)) {
				productService.listProductDiscounts();
			} else if(args[0].length() > 0) {
				basket.clear();
				basket.addProductsToCart(args);
			} else {
				throw new IllegalArgumentException(Constants.validArgumentsAre);
			}
		} else {
			throw new IllegalArgumentException(Constants.validArgumentsAre);
		}
	}
	
	/**
	 * Add products to cart 
	 * 
	 * @param args list of product names and/or barcodes which need to be added 
	 * 
	 */
	public void addProduct(String...args) {
		if(AppUtil.validateArguments(args)) {
			if(!productService.productExists(args[1], args[2])) {
				productService.addProduct(Product.newProduct(args));
				System.out.println(args[1] + " has been added in the system.");	
			} else {
				System.out.println("Product already exists with this name/barcode.");
			}
		}
	}
	
	/**
	 * List of arguments from the commandline, barcode, discount, ending discount date
	 * 
	 * @param args
	 */
	public void addProductDiscount(String...args) {
		if(args.length < 4) {
			throw new IllegalArgumentException(Constants.ArgumentMissingForDiscount);
		}
		
		if(AppUtil.isDigit(args[1], Constants.Barcode + Constants.ShouldContainDigitsOnly) &&
				AppUtil.isNumberOrDecimalPoint(args[2], Constants.Discount + Constants.ShouldContainNumberOrDecimal) &&
				AppUtil.isValidDateFormat(args[3])) {
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			try {
				productService.addProductDiscount(args[1], Double.parseDouble(args[2]), new Timestamp(format.parse(args[3]).getTime()));
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		}		
	}
}