package com.anatwine.service;

import java.sql.Timestamp;
import java.util.List;

import com.anatwine.model.DiscountOffer;
import com.anatwine.model.Product;
public interface IProductService {
     List<Product> getAllProducts();
     List<Product> getAllProductsForNames(String... names);
     List<DiscountOffer> getAllProductDiscounts();
     Product getProductById(Integer productId);
     Product getProductByName(String productName);
     Product getProductByBarcode(String barcode);
     boolean addProduct(Product product);
     void addProductDiscount(String barcode, double discount, Timestamp endDate);
     boolean productExists(String name, String barcode);
     void updateProduct(Product product);
     void deleteProduct(Integer productId);
     void listProducts();
     void listProductDiscounts();
} 