package com.anatwine.service;

import java.sql.Timestamp;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anatwine.AnatwineBasketApp;
import com.anatwine.dao.IProductDAO;
import com.anatwine.model.DiscountOffer;
import com.anatwine.model.Product;

@Service
public class ProductService implements IProductService {
	@Autowired
	private IProductDAO productDAO;

	@Override
	public Product getProductById(Integer productId) {
		Product obj = productDAO.getProductById(productId);
		return obj;
	}

	@Override
	public List<Product> getAllProducts(){
		return productDAO.getAllProducts();
	}
	
	@Override
	public List<Product> getAllProductsForNames(String... names){
		return productDAO.getAllProductsForNames(names);
	}

	@Override
	public synchronized boolean addProduct(Product Product){
		productDAO.addProduct(Product);
		return true;
	}
	
	@Override
	public synchronized boolean productExists(String name, String barcode){
		return productDAO.productExists(name, barcode);
	}

	@Override
	public void updateProduct(Product Product) {
		productDAO.updateProduct(Product);
	}

	@Override
	public void deleteProduct(Integer productId) {
		productDAO.deleteProduct(productId);
	}

	@Override
	public Product getProductByName(String productName) {
		return productDAO.getProductByName(productName);
	}

	@Override
	public Product getProductByBarcode(String barcode) {
		return null;
	}
	
	/**
	 * List the products from the database
	 * 
	 */
	@Override
	public void listProducts() {
		List<Product> products= getAllProducts();
		if(products != null && products.size() > 0) {
			int count = 1;
			System.out.println("--------------------------------------");
			for(Product product : products) {
				System.out.println("#" + count++);
				System.out.println("Name: " + product.getProductName() + 
									"\nPrice: " + product.getUnitPrice() +
									"\nBarCode: " + product.getProductBarCode() +
									"\nQuantity: " + product.getQuantity());

				System.out.println("--------------------------------------");
			}
		} else {
			System.out.println("No products found in the system." );
		}
	}

	@Override
	public void addProductDiscount(String barcode, double discount, Timestamp endDate) {
		productDAO.addProductDiscount(barcode, discount, endDate);
	}

	@Override
	public List<DiscountOffer> getAllProductDiscounts() {
		return productDAO.getAllProductDiscounts();
	}

	/**
	 * List the all product discount which are valid till now from the database
	 * 
	 */
	@Override
	public void listProductDiscounts() {
		List<DiscountOffer> discountOffers = getAllProductDiscounts();
		if(discountOffers != null && discountOffers.size() > 0) {
			int count = 1;
			System.out.println("--------------------------------------");
			for(DiscountOffer offer : discountOffers) {
				System.out.println("#" + count++);
				System.out.println("BarCode: " + offer.getProductBarCode() +
									"\nDiscount: " + offer.getDiscount() +
									"\nEnd Date: " + offer.getEndDate());

				System.out.println("--------------------------------------");
			}
		} else {
			System.out.println("No product discounts found in the system." );
		}
	}
} 